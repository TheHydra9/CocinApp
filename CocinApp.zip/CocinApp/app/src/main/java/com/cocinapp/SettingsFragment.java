package com.cocinapp;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

public class SettingsFragment extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey);

        // Preferencia para añadir recetas de ejemplo
        Preference addExampleRecipesPreference = findPreference("add_example_recipes");
        if (addExampleRecipesPreference != null) {
            addExampleRecipesPreference.setOnPreferenceClickListener(preference -> {
                addExampleRecipes();
                return true;
            });
        }

        // Preferencia para borrar la base de datos
        Preference deleteDatabasePreference = findPreference("delete_all_recipes");
        if (deleteDatabasePreference != null) {
            deleteDatabasePreference.setOnPreferenceClickListener(preference -> {
                confirmDeleteDatabase();
                return true;
            });
        }
    }

    /**
     * Añade tres recetas de ejemplo a la base de datos.
     */
    private void addExampleRecipes() {
        DatabaseHelper databaseHelper = new DatabaseHelper(getContext());

        // Rutas de las imágenes desde los recursos
        String paellaImagePath = "android.resource://" + getContext().getPackageName() + "/" + R.drawable.paella;
        String tortillaImagePath = "android.resource://" + getContext().getPackageName() + "/" + R.drawable.tortilla;
        String gazpachoImagePath = "android.resource://" + getContext().getPackageName() + "/" + R.drawable.gazpacho;

        // Se crean tres recetas de ejemplo
        Recipe recipe1 = new Recipe("Paella", "Deliciosa paella valenciana", paellaImagePath, 5, "Plato Principal", false, "60 minutos", "Arroz, Pollo, Mariscos, Pimientos, Guisantes", "Notas: Cocinar a fuego medio", "Calorías: 500");
        Recipe recipe2 = new Recipe("Tortilla de Patatas", "Clásica tortilla española", tortillaImagePath, 4, "Entrante", true, "30 minutos", "Patatas, Huevos, Cebolla, Sal", "Notas: Revolver bien los huevos", "Calorías: 300");
        Recipe recipe3 = new Recipe("Gazpacho", "Refrescante gazpacho andaluz", gazpachoImagePath, 5, "Entrante", true, "15 minutos", "Tomates, Pepino, Pimientos, Pan, Ajo", "Notas: Servir frío", "Calorías: 150");

        // Se añaden las recetas a la base de datos
        databaseHelper.insertRecipe(recipe1.getName(), recipe1.getDescription(), recipe1.getPreparationTime(), recipe1.getIngredients(), recipe1.getNotes(), recipe1.getNutrition(), recipe1.getRating(), recipe1.isVegetarian(), recipe1.getImagePath());
        databaseHelper.insertRecipe(recipe2.getName(), recipe2.getDescription(), recipe2.getPreparationTime(), recipe2.getIngredients(), recipe2.getNotes(), recipe2.getNutrition(), recipe2.getRating(), recipe2.isVegetarian(), recipe2.getImagePath());
        databaseHelper.insertRecipe(recipe3.getName(), recipe3.getDescription(), recipe3.getPreparationTime(), recipe3.getIngredients(), recipe3.getNotes(), recipe3.getNutrition(), recipe3.getRating(), recipe3.isVegetarian(), recipe3.getImagePath());

        Toast.makeText(getContext(), "Example recipes added!", Toast.LENGTH_SHORT).show();
    }

    /**
     * Muestra un cuadro de diálogo de confirmación para borrar la base de datos.
     */
    private void confirmDeleteDatabase() {
        new AlertDialog.Builder(getContext())
                .setTitle("Delete All Recipes")
                .setMessage("Are you sure you want to delete all recipes?")
                .setPositiveButton("Yes", (dialog, which) -> deleteAllRecipes())
                .setNegativeButton("No", null)
                .show();
    }

    /**
     * Borra todas las recetas de la base de datos.
     */
    private void deleteAllRecipes() {
        DatabaseHelper databaseHelper = new DatabaseHelper(getContext());
        databaseHelper.deleteAllRecipes();
        Toast.makeText(getContext(), "Goodbye recipes!", Toast.LENGTH_SHORT).show();
    }
}
