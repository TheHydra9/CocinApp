package com.cocinapp;

import android.content.Context;
import android.content.Intent;

/**
 * Clase auxiliar para manejar la creación e extracción de Intents relacionados con recetas.
 */
public class RecipeHelper {

    /**
     * Crea un Intent, incluyendo los datos de una receta.
     * @param context Contexto desde el cual se crea el Intent.
     * @param cls Clase de la actividad a la cual se enviará el Intent.
     * @param recipe La receta cuyos datos se incluirán en el Intent.
     * @return El Intent creado con los datos de la receta.
     */
    public static Intent createRecipeIntent(Context context, Class<?> cls, Recipe recipe) {
        Intent intent = new Intent(context, cls);
        intent.putExtra("recipeId", recipe.getId());
        intent.putExtra("name", recipe.getName());
        intent.putExtra("description", recipe.getDescription());
        intent.putExtra("preparationTime", recipe.getPreparationTime());
        intent.putExtra("ingredients", recipe.getIngredients());
        intent.putExtra("notes", recipe.getNotes());
        intent.putExtra("nutrition", recipe.getNutrition());
        intent.putExtra("rating", recipe.getRating());
        intent.putExtra("isVegetarian", recipe.isVegetarian());
        intent.putExtra("imagePath", recipe.getImagePath());
        return intent;
    }

    /**
     * Extrae una receta desde un Intent.
     *
     * @param intent El Intent desde el cual se extraerán los datos de la receta.
     * @return La receta extraída con todos sus datos.
     */
    public static Recipe extractRecipeFromIntent(Intent intent) {
        int recipeId = intent.getIntExtra("recipeId", -1);
        String name = intent.getStringExtra("name");
        String description = intent.getStringExtra("description");
        String preparationTime = intent.getStringExtra("preparationTime");
        String ingredients = intent.getStringExtra("ingredients");
        String notes = intent.getStringExtra("notes");
        String nutrition = intent.getStringExtra("nutrition");
        float rating = intent.getFloatExtra("rating", 0);
        boolean isVegetarian = intent.getBooleanExtra("isVegetarian", false);
        String imagePath = intent.getStringExtra("imagePath");

        Recipe recipe = new Recipe();
        recipe.setId(recipeId);
        recipe.setName(name);
        recipe.setDescription(description);
        recipe.setPreparationTime(preparationTime);
        recipe.setIngredients(ingredients);
        recipe.setNotes(notes);
        recipe.setNutrition(nutrition);
        recipe.setRating(rating);
        recipe.setVegetarian(isVegetarian);
        recipe.setImagePath(imagePath);
        return recipe;
    }
}
