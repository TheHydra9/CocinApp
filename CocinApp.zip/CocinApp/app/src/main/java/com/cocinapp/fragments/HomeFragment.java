package com.cocinapp.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.cocinapp.DatabaseHelper;
import com.cocinapp.R;
import com.cocinapp.Recipe;
import com.cocinapp.RecipeAdapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Fragmento que muestra la pantalla principal de la aplicación, incluyendo un calendario,
 * recetas recientes y recetas favoritas.
 */
public class HomeFragment extends Fragment {

    private CalendarView calendarView;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private Map<String, String> notesMap;

    /**
     * Infla el diseño de este fragmento e inicializa los componentes de la interfaz de usuario.
     *
     * @param inflater           El objeto LayoutInflater que se puede usar para inflar cualquier vista en el fragmento.
     * @param container          Si no es nulo, este es el padre al que la IU del fragmento debe adjuntarse.
     * @param savedInstanceState Si no es nulo, este fragmento se reconstruye a partir de un estado previamente guardado.
     * @return La Vista para la interfaz de usuario del fragmento, o null.
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        calendarView = view.findViewById(R.id.calendar_view);
        sharedPreferences = requireContext().getSharedPreferences("CalendarNotes", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        notesMap = new HashMap<>();

        // Obtiene el nombre de usuario de las preferencias
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String username = defaultSharedPreferences.getString("username", "");

        // Configura el saludo con "Food Lover" como valor por defecto si el nombre de usuario no está definido
        TextView greetingTextView = view.findViewById(R.id.text_view_greeting);
        if (username == null || username.isEmpty()) {
            username = getString(R.string.username);
        }
        greetingTextView.setText(getString(R.string.greeting_format, username));

        // Añade un Listener a cada día del año
        calendarView.setOnDateChangeListener((view1, year, month, dayOfMonth) -> {
            String date = year + "-" + (month + 1) + "-" + dayOfMonth;
            showNoteDialog(date);
        });

        setupRecentRecipes(view);
        setupFavoriteRecipes(view);

        return view;
    }

    /**
     * Muestra un cuadro de diálogo para añadir una nota en una fecha específica.
     * @param date La fecha seleccionada por el usuario en el calendario.
     */
    private void showNoteDialog(String date) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(R.string.day_notes_title);

        //Se crea el componente (un EditText) para permitir al usuario crear las notas.
        final EditText input = new EditText(getContext());
        input.setMinHeight(500); // Establece la altura del cuadro donde se introduce la nota
        input.setGravity(Gravity.TOP | android.view.Gravity.START); //El texto comienza en la parte superior izquierda.
        input.setHint(R.string.note_hint);
        input.setText(sharedPreferences.getString(date, ""));
        builder.setView(input);

        builder.setPositiveButton(R.string.save, (dialog, which) -> {
            String note = input.getText().toString();
            notesMap.put(date, note);
            editor.putString(date, note);
            editor.apply();
            Toast.makeText(getContext(), R.string.note_saved, Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton(R.string.cancel, (dialog, which) -> dialog.cancel());

        builder.show();
    }

    /**
     * Configura el RecyclerView para mostrar las recetas recientes.
     * @param view La vista principal del fragmento.
     */
    private void setupRecentRecipes(View view) {
        RecyclerView recentRecipesRecyclerView = view.findViewById(R.id.recycler_view_recent_recipes);
        recentRecipesRecyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));

        List<Recipe> recentRecipes = getRecentRecipes();
        RecipeAdapter recentAdapter = new RecipeAdapter(recentRecipes, getContext());
        recentRecipesRecyclerView.setAdapter(recentAdapter);
    }

    /**
     * Configura el RecyclerView para mostrar las recetas favoritas.
     * @param view La vista principal del fragmento.
     */
    private void setupFavoriteRecipes(View view) {
        RecyclerView favoriteRecipesRecyclerView = view.findViewById(R.id.recycler_view_favorite_recipes);
        favoriteRecipesRecyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));

        List<Recipe> favoriteRecipes = getFavoriteRecipes();
        RecipeAdapter favoriteAdapter = new RecipeAdapter(favoriteRecipes, getContext());
        favoriteRecipesRecyclerView.setAdapter(favoriteAdapter);
    }

    /**
     * Obtiene la lista de recetas recientes, filtrada por preferencia de recetas vegetarianas si está habilitada.
     * @return La lista de recetas recientes.
     */
    private List<Recipe> getRecentRecipes() {
        DatabaseHelper databaseHelper = new DatabaseHelper(getContext());
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        boolean showVegetarian = sharedPreferences.getBoolean("vegetarian", false);

        if (showVegetarian) {
            return databaseHelper.getRecentVegetarianRecipes();
        } else {
            return databaseHelper.getRecentRecipes();
        }
    }

    /**
     * Obtiene la lista de recetas favoritas, filtrada por preferencia de recetas vegetarianas si está habilitada.
     * @return La lista de recetas favoritas.
     */
    private List<Recipe> getFavoriteRecipes() {
        DatabaseHelper databaseHelper = new DatabaseHelper(getContext());
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        boolean showVegetarian = sharedPreferences.getBoolean("vegetarian", false);

        if (showVegetarian) {
            return databaseHelper.getFavoriteVegetarianRecipes();
        } else {
            return databaseHelper.getFavoriteRecipes();
        }
    }
}
