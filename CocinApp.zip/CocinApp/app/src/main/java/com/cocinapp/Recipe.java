package com.cocinapp;

/**
 * Clase que simula una receta de cocina.
 */
public class Recipe {
    private int id;
    private String name, description, photoUri, preparationTime, category;
    private float rating;
    private boolean isVegetarian;
    private String ingredients, notes, nutrition, imagePath;

    // Constructor
    public Recipe(String name, String description, String imagePath, float rating, String category, boolean isVegetarian, String preparationTime, String ingredients, String notes, String nutrition) {
        this.name = name;
        this.description = description;
        this.imagePath = imagePath;
        this.rating = rating;
        this.category = category;
        this.isVegetarian = isVegetarian;
        this.preparationTime = preparationTime;
        this.ingredients = ingredients;
        this.notes = notes;
        this.nutrition = nutrition;
    }

    public Recipe() {
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }


    public float getRating() { return rating; }
    public void setRating(float rating) { this.rating = rating; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public boolean isVegetarian() { return isVegetarian; }
    public void setVegetarian(boolean vegetarian) { isVegetarian = vegetarian; }

    public String getPreparationTime() { return preparationTime; }
    public void setPreparationTime(String preparationTime) { this.preparationTime = preparationTime; }

    public String getIngredients() { return ingredients; }
    public void setIngredients(String ingredients) { this.ingredients = ingredients; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getNutrition() { return nutrition; }
    public void setNutrition(String nutrition) { this.nutrition = nutrition; }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }
}
