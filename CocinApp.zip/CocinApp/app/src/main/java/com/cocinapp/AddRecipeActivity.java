package com.cocinapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Actividad para añadir una nueva receta.
 */
public class AddRecipeActivity extends AppCompatActivity {

    private EditText nameEditText, descriptionEditText, preparationTimeEditText, ingredientsEditText, notesEditText, nutritionEditText;
    private ImageView photoImageView;
    private RatingBar ratingBar;
    private Spinner categoriesSpinner;
    private CheckBox vegetarianCheckBox;
    private Button saveButton;
    private String imagePath;
    private static final int PICK_IMAGE_REQUEST = 1;

    /**
     * Método llamado cuando se crea la actividad.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_recipe);

        nameEditText = findViewById(R.id.edit_text_name);
        descriptionEditText = findViewById(R.id.edit_text_description);
        photoImageView = findViewById(R.id.image_view_photo);
        ratingBar = findViewById(R.id.rating_bar);
        categoriesSpinner = findViewById(R.id.spinner_categories);
        vegetarianCheckBox = findViewById(R.id.checkbox_vegetarian);
        preparationTimeEditText = findViewById(R.id.edit_text_preparation_time);
        ingredientsEditText = findViewById(R.id.edit_text_ingredients);
        notesEditText = findViewById(R.id.edit_text_notes);
        nutritionEditText = findViewById(R.id.edit_text_nutrition);
        saveButton = findViewById(R.id.button_save_recipe);

        photoImageView.setOnClickListener(v -> openImageSelector());
        saveButton.setOnClickListener(v -> saveRecipe());
    }

    /**
     * Abre el selector de imágenes para permitir al usuario seleccionar una imagen.
     */
    private void openImageSelector() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    /**
     * Maneja el resultado tras la selección de imagen.
     * @param requestCode Código de solicitud interno para manejar la actividad.
     * @param resultCode Código de resultado devuelto por la actividad secundaria.
     * @param data El Intent con la información de la actividad.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Verifica contengan una URI y sea la solicitud pedida.
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            // Obtiene la URI de la imagen seleccionada.
            Uri imageUri = data.getData();
            // Establece la URI de la imagen en el ImageView para mostrar la imagen seleccionada.
            photoImageView.setImageURI(imageUri);
            try {
                // Obtiene el bitmap de la imagen seleccionada a partir de la URI.
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                String uniqueImageName = "recipe_image_" + System.currentTimeMillis() + ".png";
                // Abre un FileOutputStream para guardar la imagen en el almacenamiento interno.
                FileOutputStream fos = openFileOutput(uniqueImageName, MODE_PRIVATE);
                // Comprime el bitmap en formato PNG y lo escribe en el FileOutputStream.
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);

                fos.close();
                imagePath = uniqueImageName;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * Guarda la nueva receta con la información ingresada por el usuario.
     */
    private void saveRecipe() {
        String name = nameEditText.getText().toString();
        String description = descriptionEditText.getText().toString();
        String preparationTime = preparationTimeEditText.getText().toString();
        String ingredients = ingredientsEditText.getText().toString();
        String notes = notesEditText.getText().toString();
        String nutrition = nutritionEditText.getText().toString();
        float rating = ratingBar.getRating();
        boolean isVegetarian = vegetarianCheckBox.isChecked();

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        databaseHelper.insertRecipe(name, description, preparationTime, ingredients, notes, nutrition, rating, isVegetarian, imagePath);

        Toast.makeText(this, "Recipe saved!", Toast.LENGTH_SHORT).show();
        finish();
    }
}

