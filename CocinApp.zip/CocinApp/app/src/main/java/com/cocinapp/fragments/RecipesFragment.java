package com.cocinapp.fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.cocinapp.AddRecipeActivity;
import com.cocinapp.DatabaseHelper;
import com.cocinapp.R;
import com.cocinapp.Recipe;
import com.cocinapp.RecipeAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

/**
 * Fragmento que maneja la visualización y gestión de recetas.
 */
public class RecipesFragment extends Fragment {

    private RecyclerView recyclerView;
    private RecipeAdapter recipeAdapter;
    private List<Recipe> recipeList, filteredRecipeList;
    private LinearLayoutManager layoutManager;
    private ImageButton buttonSort;
    private DatabaseHelper databaseHelper;
    private EditText searchEditText;

    // Constantes manuales para los IDs del menú
    private static final int SORT_OLDEST = 1;
    private static final int SORT_NEWEST = 2;
    private static final int SORT_AZ = 3;
    private static final int SORT_ZA = 4;

    /**
     * Método llamado para inflar el diseño del fragmento y configurar las vistas.
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return La vista inflada del fragmento.
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_recipes, container, false);
        recyclerView = view.findViewById(R.id.recycler_view_recipes);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        buttonSort = view.findViewById(R.id.button_sort);
        searchEditText = view.findViewById(R.id.search_edit_text);
        setupSortButton();
        setupSearch();

        databaseHelper = new DatabaseHelper(getContext());
        updateRecipeList();

        FloatingActionButton fabAddRecipe = view.findViewById(R.id.fab_add_recipe);
        fabAddRecipe.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), AddRecipeActivity.class);
            startActivity(intent);
        });

        return view;
    }

    /**
     * Método llamado cuando el fragmento vuelve a estar activo.
     * Aquí se actualiza la lista de recetas.
     */
    @Override
    public void onResume() {
        super.onResume();
        updateRecipeList();
    }

    /**
     * Actualiza la lista de recetas mostrada en el RecyclerView.
     * Obtiene las recetas desde la base de datos según las preferencias del usuario.
     */
    private void updateRecipeList() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        boolean showVegetarian = sharedPreferences.getBoolean("vegetarian", false);

        if (showVegetarian) {
            recipeList = databaseHelper.getVegetarianRecipes();
        } else {
            recipeList = databaseHelper.getAllRecipes();
        }

        filteredRecipeList = new ArrayList<>(recipeList);

        if (recipeAdapter == null) {
            recipeAdapter = new RecipeAdapter(filteredRecipeList, getContext()); // Pasa contexto al adaptador
            recyclerView.setAdapter(recipeAdapter);
        } else {
            recipeAdapter.updateRecipes(filteredRecipeList);
        }
    }

    /**
     * Configura el botón de ordenación para mostrar un menú de opciones.
     */
    private void setupSortButton() {
        buttonSort.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(getContext(), buttonSort);
            popup.getMenu().add(Menu.NONE, SORT_OLDEST, Menu.NONE, R.string.sort_oldest);
            popup.getMenu().add(Menu.NONE, SORT_NEWEST, Menu.NONE, R.string.sort_newest);
            popup.getMenu().add(Menu.NONE, SORT_AZ, Menu.NONE, R.string.sort_az);
            popup.getMenu().add(Menu.NONE, SORT_ZA, Menu.NONE, R.string.sort_za);
            popup.setOnMenuItemClickListener(this::onSortOptionSelected);
            popup.show();
        });
    }

    /**
     * Maneja la selección de opciones de ordenación en el menú.
     * @param item El ítem seleccionado en el menú.
     * @return true si la opción fue manejada, false de lo contrario.
     */
    private boolean onSortOptionSelected(MenuItem item) {
        switch (item.getItemId()) {
            case SORT_OLDEST:
                recipeList = databaseHelper.getRecipesByOldest();
                break;
            case SORT_NEWEST:
                recipeList = databaseHelper.getRecipesByNewest();
                break;
            case SORT_AZ:
                recipeList = databaseHelper.getRecipesAlphabetically(true);
                break;
            case SORT_ZA:
                recipeList = databaseHelper.getRecipesAlphabetically(false);
                break;
            default:
                return false;
        }
        filterRecipes(searchEditText.getText().toString().trim());
        return true;
    }

    /**
     * Configura la barra de búsqueda para filtrar recetas.
     */
    private void setupSearch() {
        searchEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                String query = searchEditText.getText().toString().trim();
                filterRecipes(query);
                return true;
            }
            return false;
        });
    }

    /**
     * Filtra la lista de recetas según la consulta de búsqueda.
     * @param query La consulta de búsqueda ingresada por el usuario.
     */
    private void filterRecipes(String query) {
        if (TextUtils.isEmpty(query)) {
            filteredRecipeList = new ArrayList<>(recipeList);
        } else {
            filteredRecipeList.clear();
            for (Recipe recipe : recipeList) {
                if (recipe.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredRecipeList.add(recipe);
                }
            }
        }
        recipeAdapter.updateRecipes(filteredRecipeList);
    }
}

