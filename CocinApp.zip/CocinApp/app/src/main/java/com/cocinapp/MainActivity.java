package com.cocinapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.preference.PreferenceManager;

import com.cocinapp.fragments.*;
import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Actividad principal que maneja la navegación entre diferentes fragmentos.
 */
public class MainActivity extends AppCompatActivity {

    private BottomNavigationView navigation;
    private FrameLayout frameLayout;
    private static final String SELECTED_TAB = "selected_tab";

    /**
     * Método llamado cuando se crea la actividad.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        navigation = findViewById(R.id.navigation_bar);
        frameLayout = findViewById(R.id.home_frame);

        // Restaura la pestaña seleccionada
        int selectedTab = getIntent().getIntExtra("selected_tab", R.id.home_id);
        navigation.setSelectedItemId(selectedTab);
        if (selectedTab == R.id.recipes_id) {
            changeFragment(new RecipesFragment());
        } else if (selectedTab == R.id.haul_id) {
            changeFragment(new HaulFragment());
        } else if (selectedTab == R.id.settings_id) {
            changeFragment(new SettingsFragment());
        } else {
            changeFragment(new HomeFragment());
        }

        navigation.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.home_id) {
                changeFragment(new HomeFragment());
            } else if (item.getItemId() == R.id.recipes_id) {
                changeFragment(new RecipesFragment());
            } else if (item.getItemId() == R.id.haul_id) {
                changeFragment(new HaulFragment());
            } else {
                changeFragment(new SettingsFragment());
            }
            saveSelectedTab(item.getItemId());
            return true;
        });
    }

    /**
     * Cambia el fragmento actual al fragmento seleccionado por el usuario.
     * @param fragment El nuevo fragmento a mostrar.
     */
    private void changeFragment(Fragment fragment) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.home_frame, fragment);
        ft.commit();
    }

    /**
     * Guarda la pestaña seleccionada en las preferencias compartidas.
     * @param tabId El Id de la pestaña seleccionada.
     */
    private void saveSelectedTab(int tabId) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(SELECTED_TAB, tabId);
        editor.apply();
    }
}
