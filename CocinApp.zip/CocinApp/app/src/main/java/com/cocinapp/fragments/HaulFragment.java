package com.cocinapp.fragments;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cocinapp.DatabaseHelper;
import com.cocinapp.R;
import com.cocinapp.Recipe;
import com.cocinapp.RecipeAdapter;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Fragmento para mostrar y filtrar recetas en base a ingredientes.
 */
public class HaulFragment extends Fragment {

    private EditText editTextIngredient;
    private ChipGroup chipGroupIngredients;
    private RecyclerView recyclerViewRecipes;
    private RecipeAdapter recipeAdapter;
    private List<Recipe> recipeList, filteredRecipeList; //Listas para las recetas y para las recetas filtradas
    private List<String> ingredientTags;

    /**
     * Infla el diseño para este fragmento e inicializa las vistas y datos.
     *
     * @param inflater           LayoutInflater para inflar el diseño
     * @param container          ViewGroup contenedor donde se añade el diseño del fragmento
     * @param savedInstanceState Bundle para guardar el estado de la instancia
     * @return La vista raíz del fragmento
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_haul, container, false);

        // Se inicializan las vistas
        editTextIngredient = view.findViewById(R.id.edit_text_ingredient);
        chipGroupIngredients = view.findViewById(R.id.chip_group_ingredients);
        recyclerViewRecipes = view.findViewById(R.id.recycler_view_recipes);

        // Se configura el RecyclerView
        recyclerViewRecipes.setLayoutManager(new LinearLayoutManager(getContext()));
        recipeAdapter = new RecipeAdapter(new ArrayList<>(), getContext());
        recyclerViewRecipes.setAdapter(recipeAdapter);

        // Se recuperan las recetas de la base de datos
        DatabaseHelper databaseHelper = new DatabaseHelper(getContext());
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        boolean showVegetarian = sharedPreferences.getBoolean("vegetarian", false);

        // Comprueba la preferencia de "vegetariano"
        if (showVegetarian) {
            recipeList = databaseHelper.getVegetarianRecipes();
        } else {
            recipeList = databaseHelper.getAllRecipes();
        }

        filteredRecipeList = new ArrayList<>(recipeList);
        ingredientTags = new ArrayList<>();

        // Configura el listener para los ingredientes que va dando el usuario
        editTextIngredient.setOnEditorActionListener((v, actionId, event) -> {
            // Verifica si la acción realizada es Intro o Done (me explotaba esta parte por verificar solo el teclado virtual y no el físico)
            if (actionId == EditorInfo.IME_ACTION_DONE || (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                // Recupera el texto y elimina los espacios
                String ingredient = editTextIngredient.getText().toString().trim();
                // Verifica si el texto ingresado no está vacío y no está ya en la lista de etiquetas de ingredientes
                if (!TextUtils.isEmpty(ingredient) && !ingredientTags.contains(ingredient)) {
                    addIngredientTag(ingredient);
                    filterRecipes();
                    editTextIngredient.setText("");
                }
                return true;
            }
            return false;
        });


        return view;
    }

    /**
     * Añade una nueva etiqueta de ingredientes y actualiza la lista de recetas.
     *
     * @param ingredient Ingrediente a añadir
     */
    private void addIngredientTag(String ingredient) {
        //Añade el ingrediente al filtrado
        ingredientTags.add(ingredient);

        //Crea un Chip para mostrar al usuario el ingrediente selecionado.
        Chip chip = new Chip(getContext());
        chip.setText(ingredient);
        chip.setCloseIconVisible(true);
        //Si se hace click sobre él, se elimina el chip y el filtrado.
        chip.setOnCloseIconClickListener(v -> {
            chipGroupIngredients.removeView(chip);
            ingredientTags.remove(ingredient);
            filterRecipes();
        });
        chipGroupIngredients.addView(chip);
    }

    /**
     * Filtra la lista de recetas según los ingredientes ingresados y actualiza el RecyclerView.
     */
    private void filterRecipes() {
        //Limpia, si había, la anterior lista.
        filteredRecipeList.clear();
        //Recorre todas las recetas buscando recetas que contengan los ingredientes.
        for (Recipe recipe : recipeList) {
            boolean matchesAllIngredients = true;
            for (String ingredient : ingredientTags) {
                if (!recipe.getIngredients().toLowerCase().contains(ingredient.toLowerCase())) {
                    matchesAllIngredients = false;
                    break;
                }
            }
            if (matchesAllIngredients) {
                filteredRecipeList.add(recipe);
            }
        }
        recipeAdapter.updateRecipes(filteredRecipeList);
    }
}
