package com.cocinapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Actividad para editar una receta.
 */
public class EditRecipeActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private EditText editTextName, editTextDescription, editTextPreparationTime, editTextIngredients, editTextNotes, editTextNutrition;
    private ImageView imageViewPhoto;
    private RatingBar ratingBar;
    private Spinner spinnerCategories;
    private CheckBox checkboxVegetarian;
    private Button buttonSaveRecipe;
    private String imagePath;
    private boolean imageChanged = false; // Variable para verificar si la imagen ha cambiado cuando el usuario entra a la galería.

    private Recipe recipe;

    /**
     * Método llamado cuando se crea la actividad.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_recipe);

        editTextName = findViewById(R.id.edit_text_name);
        editTextDescription = findViewById(R.id.edit_text_description);
        editTextPreparationTime = findViewById(R.id.edit_text_preparation_time);
        editTextIngredients = findViewById(R.id.edit_text_ingredients);
        editTextNotes = findViewById(R.id.edit_text_notes);
        editTextNutrition = findViewById(R.id.edit_text_nutrition);
        imageViewPhoto = findViewById(R.id.image_view_photo);
        ratingBar = findViewById(R.id.rating_bar);
        spinnerCategories = findViewById(R.id.spinner_categories);
        checkboxVegetarian = findViewById(R.id.checkbox_vegetarian);
        buttonSaveRecipe = findViewById(R.id.button_save_recipe);

        Intent intent = getIntent();
        recipe = RecipeHelper.extractRecipeFromIntent(intent);

        editTextName.setText(recipe.getName());
        editTextDescription.setText(recipe.getDescription());
        editTextPreparationTime.setText(recipe.getPreparationTime());
        editTextIngredients.setText(recipe.getIngredients());
        editTextNotes.setText(recipe.getNotes());
        editTextNutrition.setText(recipe.getNutrition());
        ratingBar.setRating(recipe.getRating());
        checkboxVegetarian.setChecked(recipe.isVegetarian());

        if (recipe.getImagePath() != null && !recipe.getImagePath().isEmpty()) {
            Picasso.get().load(new File(getFilesDir(), recipe.getImagePath())).into(imageViewPhoto);
        } else {
            imageViewPhoto.setImageResource(R.drawable.placeholder_image); // Imagen por defecto si no hay imagen
        }

        // Listener para editar la imagen actual.
        imageViewPhoto.setOnClickListener(v -> openImageSelector());

        // Listener para guardar los cambios introducidos
        buttonSaveRecipe.setOnClickListener(v -> saveRecipe());
    }

    /**
     * Guarda la receta con la información actualizada.
     */
    private void saveRecipe() {
        // Obtiene los datos dados por el usuario
        String name = editTextName.getText().toString();
        String description = editTextDescription.getText().toString();
        String preparationTime = editTextPreparationTime.getText().toString();
        String ingredients = editTextIngredients.getText().toString();
        String notes = editTextNotes.getText().toString();
        String nutrition = editTextNutrition.getText().toString();
        float rating = ratingBar.getRating();
        boolean isVegetarian = checkboxVegetarian.isChecked();

        // Si la imagen no ha cambiado, mantener la imagen original
        if (!imageChanged) {
            imagePath = recipe.getImagePath();
        }

        // Actualiza el objeto con la receta
        recipe.setName(name);
        recipe.setDescription(description);
        recipe.setPreparationTime(preparationTime);
        recipe.setIngredients(ingredients);
        recipe.setNotes(notes);
        recipe.setNutrition(nutrition);
        recipe.setRating(rating);
        recipe.setVegetarian(isVegetarian);
        recipe.setImagePath(imagePath); // Actualizar la ruta de la imagen

        // Guarda los cambios en la base de datos
        DatabaseHelper databaseHelper = new DatabaseHelper(EditRecipeActivity.this);
        databaseHelper.updateRecipe(recipe);

        Toast.makeText(EditRecipeActivity.this, "¡Receta actualizada con éxito!", Toast.LENGTH_SHORT).show();

        //Pasa de vuelta al MainActivity, para poder actualizar las listas y mostrar los nuevos datos de la BD.
        Intent intent = new Intent(EditRecipeActivity.this, MainActivity.class);
        intent.putExtra("selected_tab", R.id.recipes_id); // Pestaña de recetas seleccionada
        startActivity(intent);

        finish();
    }

    /**
     * Abre el selector de imágenes.
     */
    private void openImageSelector() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    /**
     * Maneja el resultado tras la selección de imagen, es decir cuando la actividad que se comenzó
     * tiene un resultado.
     *
     * @param requestCode Código de solicitud interno para manejar la actividad.
     * @param resultCode Código de resultado devuelto por la actividad secundaria.
     * @param data El Intent con la información de la actividad.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            imageViewPhoto.setImageURI(imageUri);
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                String uniqueImageName = "recipe_image_" + System.currentTimeMillis() + ".png";
                FileOutputStream fos = openFileOutput(uniqueImageName, MODE_PRIVATE);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                fos.close();
                imagePath = uniqueImageName;
                imageChanged = true; // Indica que la imagen ha cambiado
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
