package com.cocinapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import com.github.clans.fab.FloatingActionButton;
import com.squareup.picasso.Picasso;
import java.io.File;

/**
 * Actividad para mostrar los detalles de una receta.
 */
public class RecipeDetailActivity extends AppCompatActivity {

    private static final int EDIT_RECIPE_REQUEST = 1;

    private ImageView imageView;
    private TextView textViewName, textViewDescription, textViewPreparationTime, textViewIngredients, textViewNotes, textViewNutrition;
    private RatingBar ratingBar;
    private ImageView vegetarianImageView;
    private FloatingActionButton fabDeleteRecipe, fabEditRecipe;

    private Recipe recipe;

    /**
     * Método llamado cuando se crea la actividad
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail);

        imageView = findViewById(R.id.image_view_photo);
        textViewName = findViewById(R.id.text_view_name);
        textViewDescription = findViewById(R.id.text_view_description);
        textViewPreparationTime = findViewById(R.id.text_view_preparation_time);
        textViewIngredients = findViewById(R.id.text_view_ingredients);
        textViewNotes = findViewById(R.id.text_view_notes);
        textViewNutrition = findViewById(R.id.text_view_nutrition);
        ratingBar = findViewById(R.id.rating_bar);
        vegetarianImageView = findViewById(R.id.image_view_vegetarian);
        fabDeleteRecipe = findViewById(R.id.button_delete_recipe);
        fabEditRecipe = findViewById(R.id.button_edit_recipe);

        Intent intent = getIntent();
        recipe = RecipeHelper.extractRecipeFromIntent(intent);

        setRecipeData();

        fabDeleteRecipe.setOnClickListener(v -> deleteRecipe());

        fabEditRecipe.setOnClickListener(v -> {
            Intent editIntent = RecipeHelper.createRecipeIntent(RecipeDetailActivity.this, EditRecipeActivity.class, recipe);
            startActivityForResult(editIntent, EDIT_RECIPE_REQUEST);
        });
    }

    /**
     * Maneja el resultado de la actividad de edición.
     * Actualiza la receta y sus datos si la edición ha sido exitosa.
     *
     * @param requestCode Código de solicitud interno para manejar la actividad.
     * @param resultCode Código de resultado devuelto por la actividad secundaria.
     * @param data El Intent con la información de la actividad.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EDIT_RECIPE_REQUEST && resultCode == RESULT_OK && data != null) {
            recipe = RecipeHelper.extractRecipeFromIntent(data);
            setRecipeData();
            Toast.makeText(RecipeDetailActivity.this, "Recipe updated successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Establece los datos de la receta seleccionada.
     */
    private void setRecipeData() {
        textViewName.setText(recipe.getName());
        textViewDescription.setText(recipe.getDescription());
        textViewPreparationTime.setText(recipe.getPreparationTime());
        textViewIngredients.setText(recipe.getIngredients());
        textViewNotes.setText(recipe.getNotes());
        textViewNutrition.setText(recipe.getNutrition());
        ratingBar.setRating(recipe.getRating());

        if (recipe.getImagePath() != null && !recipe.getImagePath().isEmpty()) {
            Picasso.get().load(new File(getFilesDir(), recipe.getImagePath())).into(imageView);
        } else {
            imageView.setImageResource(R.drawable.placeholder_image); // Imagen por defecto si no hay imagen
        }

        if (recipe.isVegetarian()) {
            vegetarianImageView.setVisibility(View.VISIBLE);
        } else {
            vegetarianImageView.setVisibility(View.GONE);
        }
    }

    /**
     * Borra la receta actual de la base de datos.
     */
    private void deleteRecipe() {
        DatabaseHelper databaseHelper = new DatabaseHelper(RecipeDetailActivity.this);
        boolean result = databaseHelper.deleteRecipe(recipe.getId());

        if (result) {
            Toast.makeText(RecipeDetailActivity.this, "Recipe deleted successfully!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(RecipeDetailActivity.this, "Failed to delete recipe!", Toast.LENGTH_SHORT).show();
        }
    }
}
