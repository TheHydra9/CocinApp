package com.cocinapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Helper para manejar la base de datos de recetas en SQLite.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "recipes.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_RECIPES = "recipes";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_DESCRIPTION = "description";

    /**
     * Constructor para inicializar el helper de base de datos.
     * @param context Contexto de la aplicación.
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_RECIPES_TABLE = "CREATE TABLE " + TABLE_RECIPES + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NAME + " TEXT,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + "preparation_time TEXT,"
                + "ingredients TEXT,"
                + "notes TEXT,"
                + "nutrition TEXT,"
                + "rating REAL,"
                + "is_vegetarian INTEGER,"
                + "image_path TEXT"
                + ")";
        db.execSQL(CREATE_RECIPES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECIPES);
        onCreate(db);
    }

    /**
     * Añade una receta a la base de datos.
     *
     * @param name            Nombre de la receta
     * @param description     Descripción de la receta
     * @param preparationTime Tiempo de preparación
     * @param ingredients     Ingredientes
     * @param notes           Notas
     * @param nutrition       Información nutricional
     * @param rating          Calificación
     * @param isVegetarian    Indicador de si es vegetariana
     * @param imagePath       Ruta de la imagen
     */
    public void insertRecipe(String name, String description,
                             String preparationTime, String ingredients, String notes, String nutrition,
                             float rating, boolean isVegetarian, String imagePath) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("description", description);
        values.put("preparation_time", preparationTime);
        values.put("ingredients", ingredients);
        values.put("notes", notes);
        values.put("nutrition", nutrition);
        values.put("rating", rating);
        values.put("is_vegetarian", isVegetarian ? 1 : 0);
        values.put("image_path", imagePath);

        db.insert("recipes", null, values);
        db.close();
    }

    /**
     * Actualiza una receta en la base de datos.
     * @param recipe La receta a actualizar.
     */
    public void updateRecipe(Recipe recipe) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", recipe.getName());
        values.put("description", recipe.getDescription());
        values.put("preparation_time", recipe.getPreparationTime());
        values.put("ingredients", recipe.getIngredients());
        values.put("notes", recipe.getNotes());
        values.put("nutrition", recipe.getNutrition());
        values.put("rating", recipe.getRating());
        values.put("is_vegetarian", recipe.isVegetarian() ? 1 : 0);
        values.put("image_path", recipe.getImagePath());
        db.update("recipes", values, "id = ?", new String[]{String.valueOf(recipe.getId())});
        db.close();
    }

    /**
     * Obtiene todas las recetas de la base de datos.
     * @return Una lista de todas las recetas.
     */
    @SuppressLint("Range")
    public List<Recipe> getAllRecipes() {
        return getRecipes("SELECT * FROM " + TABLE_RECIPES);
    }

    /**
     * Recibe una consulta para obtener recetas de la base de datos en un orden dado.
     * @param query La consulta SQL a ejecutar.
     * @return Una lista de recetas según la consulta.
     */
    @SuppressLint("Range")
    public List<Recipe> getRecipes(String query) {
        List<Recipe> recipes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                Recipe recipe = new Recipe();
                recipe.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID))); // Obtener el ID
                recipe.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
                recipe.setDescription(cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION)));
                recipe.setPreparationTime(cursor.getString(cursor.getColumnIndex("preparation_time")));
                recipe.setIngredients(cursor.getString(cursor.getColumnIndex("ingredients")));
                recipe.setNotes(cursor.getString(cursor.getColumnIndex("notes")));
                recipe.setNutrition(cursor.getString(cursor.getColumnIndex("nutrition")));
                recipe.setRating(cursor.getFloat(cursor.getColumnIndex("rating")));
                recipe.setVegetarian(cursor.getInt(cursor.getColumnIndex("is_vegetarian")) == 1);
                recipe.setImagePath(cursor.getString(cursor.getColumnIndex("image_path")));
                recipes.add(recipe);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return recipes;
    }

    /**
     * Obtiene recetas ordenadas  segpor una columna específica.
     * @param column    La columna por la cual ordenar.
     * @param ascending Si las recetas deben ser ordenadas en orden ascendente.
     * @return Una lista de recetas ordenadas.
     */
    public List<Recipe> getRecipesSortedBy(String column, boolean ascending) {
        String order = ascending ? "ASC" : "DESC";
        String query = "SELECT * FROM " + TABLE_RECIPES + " ORDER BY " + column + " " + order;
        return getRecipes(query);
    }

    /**
     * Obtiene las recetas ordenadas por más recientes.
     * @return Una lista de las recetas más recientes.
     */
    public List<Recipe> getRecipesByNewest() {
        return getRecipesSortedBy(COLUMN_ID, false);
    }

    /**
     * Obtiene las recetas ordenadas por más antiguas.
     * @return Una lista de las recetas más antiguas.
     */
    public List<Recipe> getRecipesByOldest() {
        return getRecipesSortedBy(COLUMN_ID, true);
    }

    /**
     * Obtiene las recetas ordenadas alfabéticamente.
     * @param ascending true si ascendente, false si descendente
     * @return Una lista de recetas ordenadas alfabéticamente.
     */
    public List<Recipe> getRecipesAlphabetically(boolean ascending) {
        return getRecipesSortedBy(COLUMN_NAME, ascending);
    }

    /**
     * Obtiene las recetas más recientes.
     * @return Una lista de las recetas más recientes.
     */
    @SuppressLint("Range")
    public List<Recipe> getRecentRecipes() {
        String query = "SELECT * FROM " + TABLE_RECIPES + " ORDER BY " + COLUMN_ID + " DESC LIMIT 10";
        return getRecipes(query);
    }

    /**
     * Obtiene las recetas favoritas.
     * @return Una lista de las recetas favoritas.
     */
    @SuppressLint("Range")
    public List<Recipe> getFavoriteRecipes() {
        String query = "SELECT * FROM " + TABLE_RECIPES + " WHERE rating >= 4 ORDER BY rating DESC";
        return getRecipes(query);
    }

    /**
     * Obtiene las recetas vegetarianas.
     * @return Una lista de las recetas vegetarianas.
     */
    public List<Recipe> getVegetarianRecipes() {
        String query = "SELECT * FROM " + TABLE_RECIPES + " WHERE is_vegetarian = 1";
        return getRecipes(query);
    }

    /**
     * Obtiene las recetas vegetarianas más recientes.
     * @return Una lista de las recetas vegetarianas más recientes.
     */
    public List<Recipe> getRecentVegetarianRecipes() {
        String query = "SELECT * FROM " + TABLE_RECIPES + " WHERE is_vegetarian = 1 ORDER BY " + COLUMN_ID + " DESC LIMIT 10";
        return getRecipes(query);
    }

    /**
     * Obtiene las recetas vegetarianas favoritas.
     * @return Una lista de las recetas vegetarianas favoritas.
     */
    public List<Recipe> getFavoriteVegetarianRecipes() {
        String query = "SELECT * FROM " + TABLE_RECIPES + " WHERE is_vegetarian = 1 AND rating >= 4 ORDER BY rating DESC";
        return getRecipes(query);
    }

    /**
     * Borra una receta de la base de datos.
     * @param recipeId Id de la receta a borrar.
     */
    public boolean deleteRecipe(int recipeId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("recipes", "id = ?", new String[]{String.valueOf(recipeId)});
        db.close();
        return result > 0;
    }

    /**
     * Borra todas las recetas de la base de datos.
     */
    public void deleteAllRecipes() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("recipes", null, null);
        db.close();
    }
}

