package com.cocinapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Adaptador para manejar y mostrar las recetas en un RecyclerView.
 */
public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.RecipeViewHolder> {

    private List<Recipe> recipeList;
    private Context context;

    /**
     * Constructor para inicializar el adaptador de recetas.
     * @param recipeList Lista de recetas a mostrar.
     * @param context Contexto de la aplicación.
     */
    public RecipeAdapter(List<Recipe> recipeList, Context context) {
        this.recipeList = recipeList != null ? recipeList : new ArrayList<>();
        this.context = context;
    }

    /**
     * Crea nuevas vistas para las recetas
     * @param parent El ViewGroup al que se añadirá la nueva vista después de vincularla a una posición de adaptador.
     * @param viewType El tipo de vista de la nueva vista.
     * @return Una nueva instancia de RecipeViewHolder.
     */
    @Override
    public RecipeViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_recipe_adapter, parent, false);
        return new RecipeViewHolder(view);
    }

    /**
     * Reemplaza el contenido de una vista que ya existia.
     * @param holder El RecipeViewHolder al cual se debe añadir la nueva información de la receta.
     * @param position La posición en el adaptador.
     */
    @Override
    public void onBindViewHolder(RecipeViewHolder holder, int position) {
        Recipe recipe = recipeList.get(position);
        holder.nameTextView.setText(recipe.getName());
        holder.preparationTextView.setText(recipe.getPreparationTime());
        holder.ratingBar.setRating(recipe.getRating());

        if (recipe.getImagePath() != null && !recipe.getImagePath().isEmpty()) {
            Picasso.get().load(new File(holder.itemView.getContext().getFilesDir(), recipe.getImagePath()))
                    .placeholder(R.drawable.placeholder_image)
                    //.error(R.drawable.error_image)
                    .into(holder.photoImageView);
        } else {
            holder.photoImageView.setImageResource(R.drawable.placeholder_image); // Imagen por defecto si no hay imagen
        }

        if (recipe.isVegetarian()) {
            holder.vegetarianImageView.setVisibility(View.VISIBLE);
        } else {
            holder.vegetarianImageView.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(v -> {
            Intent intent = RecipeHelper.createRecipeIntent(context, RecipeDetailActivity.class, recipe);
            context.startActivity(intent);
        });
    }

    /**
     * Devuelve el tamaño del conjunto de datos (invocado por el layout manager).
     * @return El tamaño de la lista de recetas.
     */
    @Override
    public int getItemCount() {
        return recipeList.size();
    }

    /**
     * Clase interna que proporciona una referencia a las vistas para cada elemento de datos.
     */
    public static class RecipeViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView, preparationTextView;
        ImageView photoImageView, vegetarianImageView;
        RatingBar ratingBar;

        /**
         * Inicializa las vistas para cada elemento de datos.
         *
         * @param itemView La vista del elemento.
         */
        public RecipeViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.text_view_name);
            preparationTextView = itemView.findViewById(R.id.text_view_preparation_time);
            photoImageView = itemView.findViewById(R.id.image_view_photo);
            ratingBar = itemView.findViewById(R.id.rating_bar);
            vegetarianImageView = itemView.findViewById(R.id.image_view_vegetarian);
        }
    }

    /**
     * Actualiza la lista de recetas y notifica al adaptador de los cambios.
     * @param newRecipes La nueva lista de recetas.
     */
    public void updateRecipes(List<Recipe> newRecipes) {
        recipeList.clear();
        if (newRecipes != null) {
            recipeList.addAll(newRecipes);
        }
        notifyDataSetChanged();
    }
}
